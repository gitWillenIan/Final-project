
Class = require 'class'
push = require 'push'
require 'Ball'
require 'Paddle'

WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
 
VITRUAL_WIDTH = 432
VIRTUAL_HEIGHT = 243

PADEL_SPEED = 200

function love.load()
    math.randomseed(os.time())

    love.graphics.setDefaultFilter('nearest', 'nearest')
    love.window.setTitle('Pong Game Final!')

    smallFont = love.graphics.newFont('Minecraft.ttf', 8)
    scoreFont = love.graphics.newFont('Minecraft.ttf', 32)
    victoryFont = love.graphics.newFont('Minecraft.ttf', 24)
    -- Generates The starting player 1 score
    player1score = 0
    player2score = 0

    -- Generates The Starting player 1 Score
    paddle1 = Paddle(5,20,5,20 )
    paddle2 = Paddle(VITRUAL_WIDTH - 10, VIRTUAL_HEIGHT - 30 , 5 , 20)
    -- Generates the starting positon of ball and speed
    ---startBall()
    ball = Ball(VITRUAL_WIDTH / 2 - 2  , VIRTUAL_HEIGHT / 2 -2 , 5 , 5 )

    servingPlayer = math.random(2) == 1 and 1 or 2
    winningPlayer = 0

    if servingPlayer == 1 then
        ball.dx = 100
    else
        ball.dx = -100
    end




    push:setupScreen(VITRUAL_WIDTH, VIRTUAL_HEIGHT, WINDOW_WIDTH, WINDOW_HEIGHT,{
        fullscreen = false,
        vsync = true,
        resizable = false
    })

    gameState = 'start'

end

function startBall()
    -- Generates the starting positon of ball and speed
    ballX = VITRUAL_WIDTH / 2 - 2
    ballY = VIRTUAL_HEIGHT / 2 -2
    ballDX = math.random(2) == 1 and -100 or 100
    ballDY = math.random(-50,50)
end

function collision()

end



function love.update(dt)

    if ball.x <= 0 then
        player2score = player2score + 1
        ball:reset()
        ball.dx = 100
        servingPlayer = 1

        if player2score >= 3 then
            gameState = 'victory'
            winningPlayer = 2
        end

    end

    if ball.x >= VITRUAL_WIDTH - 4 then
        player1score = player1score + 1
        ball:reset()
        ball.dx = -100
        servingPlayer = 2

        if player1score >= 3 then
            gameState = 'victory'
            winningPlayer = 1
        end

    end


    if ball:collides(paddle1) then
        --deflect ball to the right
        ball.dx = - ball.dx
    end

    if ball:collides(paddle2) then 
        --deflect ball to the left
        ball.dx = - ball.dx
    end 

    if ball.y <= 0 then 
        ball.dy = - ball.dy
        ball.y = 0
    end

    if ball.y >= VIRTUAL_HEIGHT - 4 then 
        ball.dy = - ball.dy
        ball.y = VIRTUAL_HEIGHT - 4
    end


    -- Player 1 Controls
    if love.keyboard.isDown('w') then
        paddle1.dy = - PADEL_SPEED
    elseif love.keyboard.isDown('s') then
        paddle1.dy =  PADEL_SPEED
    else
        paddle1.dy = 0
    end
    
    -- Player 2 Controls
    if love.keyboard.isDown('up') then
        paddle2.dy =  - PADEL_SPEED
    elseif love.keyboard.isDown('down') then
        paddle2.dy =   PADEL_SPEED
    else
        paddle2.dy =  0
    end

    if gameState == 'play' then  
        ball:update(dt)
    end

    paddle1:update(dt)
    paddle2:update(dt)
end


function love.keypressed(key)
    if key == 'escape' then
        love.event.quit()


    elseif key == 'enter' or key == 'return' then
        if gameState == 'start' then
            gameState = 'serve'
        elseif gameState == 'victory' then
            gameState = 'start'
            player1score = 0
            player2score = 0
        elseif gameState == 'serve' then
            gameState = 'play'
        end
    end
        
end

function love.draw()
    
    push:apply('start') --- This lets us use the push file that braught in

    --- Must divided 255 for the bit stuff, changes the background based on rgb values
    love.graphics.clear(40 / 255 ,45 /255,52 /255,255 /255)
    ---love.graphics.setFont(smallFont)    
    if gameState == 'start' then
        love.graphics.setFont(smallFont)
        love.graphics.printf("Welcome to Pong!", 0 , 10, VITRUAL_WIDTH, 'center')
        love.graphics.printf("Press Enter to Play!", 0 ,20, VITRUAL_WIDTH, 'center')
    elseif gameState == 'serve' then
        love.graphics.setFont(smallFont)
        love.graphics.printf("Player: " .. tostring(servingPlayer) .. "'s turn!" ,
        0 , 10, VITRUAL_WIDTH, 'center')
        love.graphics.printf("Press Enter to Serve!", 0 ,20, VITRUAL_WIDTH, 'center')
    elseif gameState == 'victory' then
        love.graphics.setFont(victoryFont)
        love.graphics.printf("Player: " .. tostring(winningPlayer) .. " has won!" , 0 , 10, VITRUAL_WIDTH, 'center')
        love.graphics.setFont(smallFont)
        player1score = 0
        player2score = 0
        love.graphics.printf("Press Enter to play new Game", 0 , 36 , VITRUAL_WIDTH, 'center')
        love.graphics.printf("Press ESCAPE to quit", 0 , 50 , VITRUAL_WIDTH, 'center')
        
    elseif gameState == 'play' then
        --Nothing
    end
    ---Ball Creation
        ---love.graphics.rectangle('fill', ballX , ballY , 4 , 4)
    ball:render()
    
    ---Player 1 Paddle Creation
    
    paddle1:render()
        --- old form of making it: love.graphics.rectangle('fill', 5 , Player1Y , 5 ,20)
    ---Player 2 Paddle Creation
    paddle2:render()
   
    ---Creates Score Board
    love.graphics.setFont(scoreFont)
    love.graphics.print(player1score, VITRUAL_WIDTH / 2 - 50 , VIRTUAL_HEIGHT / 3)
    love.graphics.print(player2score, VITRUAL_WIDTH / 2 + 30 , VIRTUAL_HEIGHT / 3)

    displayFPS()

    push:apply('end') --- This Closes it and stops us from using the raster graphics stuff


end


function displayFPS()
    love.graphics.setColor(0,1,0,1)
    love.graphics.setFont(smallFont)
    love.graphics.print('FPS: ' .. tostring( love.timer.getFPS() ), 40 , 20)
    love.graphics.setColor(1,1,1,1)
end


